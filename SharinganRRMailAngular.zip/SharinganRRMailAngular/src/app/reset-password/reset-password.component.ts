import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MailService } from '../mail.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {
  constructor(private route: Router, private http: HttpClient, private service: MailService, private toastr: ToastrService) { }

  ngOnInit() {
  }
  confirmPassword(form) {
    console.log(form.value);
    if( form.value.password === form.value.cpassword ){
      this.http.get(`${this.service.url}/changePassword/${form.value.email}/${form.value.password}`).subscribe( resp => {
        if ( resp !== null) {
          this.toastr.warning('Password Changed');
          console.log(resp);
        } else {
          this.toastr.warning(' Failed To Change The Password');
  
        }
      });
    } else {
      this.toastr.warning(' Both Password Must Be Same ');
    }
  }

}
